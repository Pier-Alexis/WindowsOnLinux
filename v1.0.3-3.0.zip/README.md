# Windows On Linux
Windows on Linux program to run application and games. *Basic App for now*.

Copyright (c) 2024 Senka107

This program was designed to run applications designed for Windows on Linux. Installation does not require any special packages already installed, the installer will install them automatically from apt-get. This program was designed by Senka107, a small developer in C#, C, C++, Ruby, HTML, ASM and python. Using Wine and DirectX to Vulkan.
